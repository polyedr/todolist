from django.apps import AppConfig


class Todo_postsConfig(AppConfig):
    name = 'todo_posts'
